package respository

import "errors"

var (
	ErrRecordNotFound = errors.New("record not found")
)
